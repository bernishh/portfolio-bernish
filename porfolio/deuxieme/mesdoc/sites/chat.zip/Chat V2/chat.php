<?php
session_start();
if(!isset($_SESSION["mail"])){//si la variable de session mail n'existe pas
    header("location:connexion.php");
}
$id = mysqli_connect("localhost:3307","root","","chat2");
$pseudo = $_SESSION["nom"];
if(isset($_POST["bout"])){
    
    $message = $_POST["message"];
    $destinataire = $_POST["destinataire"];
    $req = "insert into messages (idm,pseudo,message,date,destinataire)
            values (null,'$pseudo','$message', now(), '$destinataire')";
    mysqli_query($id,$req);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <a href="deconnexion.php">Deconnexion</a><br>
    <?php 
    if($_SESSION["niveau"] == 2){
        echo '<a href="ajoutUser.php">Ajouter un utilisateur</a>';
    }
    ?>
    <div class="container">
       <header>
            <h1>Bonjour <?php echo $_SESSION["prenom"]?>,  Chattez'en direct! Chatbox</h1>
       </header> 
        <div class="messages">
            <ul>
                <?php
                $req = "select * from messages 
                        where destinataire = '$pseudo'
                        or destinataire = 'tous'
                        order by date";
                $res = mysqli_query($id,$req);
                while($ligne = mysqli_fetch_assoc($res)){
                    echo "<li class='message'>".$ligne["date"]." - "
                               .$ligne["pseudo"]." - "
                               .$ligne["message"].
                        "</li>";
                }
                ?>
                
            </ul>
        </div>
        <div class="formulaire">
            <form action="" method="post">
                
                <input type="text" name="message" placeholder="Message : " required>
                <select name="destinataire">
                    <option value="tous">tous</option>
                    <?php
                    $req = "select * from user order by nom";
                    $res = mysqli_query($id,$req);
                    while($ligne = mysqli_fetch_assoc($res)){
                        echo "<option>".$ligne["nom"]."</option>";
                    }
                    ?>
                </select>
                <input type="submit" value="Envoyer" name="bout">
            </form>
        </div>
    </div>
</body>
</html>